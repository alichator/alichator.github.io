#!/usr/bin/python3
import typing
def add(x:str, y:str) -> str:
    return x + y
print(add(2,2))
print(add("ab", "cd"))
