"""One-line summary: lots of things.

Now a longer description follows. Here you can write a lot. Honestly, you
shouldn't be putting all these packages together because they have nothing in
common. But at least you can use markdown here: *italics* **bold**. My favorite
variable name is `nothing`. By the way, some people claim that this is the most
beautiful equation: \[e^{i\pi} + 1 = 0\]

.. warning::
    The interface here is unstable.
"""
