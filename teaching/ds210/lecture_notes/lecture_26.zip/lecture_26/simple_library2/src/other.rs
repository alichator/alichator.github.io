use librs;
fn main() {
   println!("This is other using a library");
   librs::bar::say_something();
}
