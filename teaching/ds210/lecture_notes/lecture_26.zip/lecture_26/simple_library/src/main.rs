use utils::bar;
mod utils;
fn main() {
   println!("This is main binary");
   bar::say_something();
}
