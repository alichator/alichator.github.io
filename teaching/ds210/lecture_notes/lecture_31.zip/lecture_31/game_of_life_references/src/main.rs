use chrono::Local;
use clap::Parser;
use std::ops::Sub;
use std::thread;
use std::time;

#[derive(Parser, Debug)]
#[command(author, version, about, long_about = None)]

struct Args {
    /// Board size
    #[arg(short, long, default_value_t = 64)]
    size: usize,

    /// Display the board
    #[arg(short, long, default_value_t = false)]
    display: bool,

    /// Lag between iterations in milliseconds
    #[arg(short, long, default_value_t = 0)]
    lag: u64,

    // Number of iterations
    #[arg(short, long, default_value_t = 10)]
    iters: u32,

    // Random initialization or not
    #[arg(short, long, default_value_t = false)]
    rnd: bool,
}

pub struct BoardResources {
    pub board: Vec<Vec<i32>>,
}

pub struct Board<'a> {
    pub n: usize,
    pub cur: &'a mut BoardResources,
    pub next: &'a mut BoardResources,
}

impl<'a> Board<'a> {
    pub fn new(n: usize, cur: &'a mut BoardResources, next: &'a mut BoardResources) -> Board<'a> {
        Board { n, cur, next }
    }

    fn neighbors(i: usize, j: usize, n: usize) -> Vec<(usize, usize)> {
        let i_l = (i + n - 1) % n;
        let i_r = (i + 1) % n;
        let j_u = (j + n - 1) % n;
        let j_d = (j + 1) % n;
        return vec![
            (i_l, j_u),
            (i, j_u),
            (i_r, j_u),
            (i_l, j),
            (i_r, j),
            (i_l, j_d),
            (i, j_d),
            (i_r, j_d),
        ];
    }

    pub fn board_render(&self, iters: u32) {
        println!("Iteration {}\n", iters);
        let mut output = String::new();
        output.push(' ');
        for i in 0..self.n {
            for j in 0..self.n {
                let ch;
                if self.cur.board[i][j] == 0 {
                    ch = '_';
                } else {
                    ch = 'x';
                }
                output.push(ch);
            }
            output.push_str("\n ");
        }
        output.push_str("\n");
        println!("{}", output);
    }

    pub fn update(&mut self) {
        for i in 0..self.n {
            for j in 0..self.n {
                let nbrs = Self::neighbors(i, j, self.n);
                let mut sum = 0;
                for n in &nbrs {
                    sum += self.cur.board[n.0][n.1];
                }
                if sum == 2 {
                    self.next.board[i][j] = self.cur.board[i][j];
                } else if sum == 3 {
                    self.next.board[i][j] = 1;
                } else {
                    self.next.board[i][j] = 0;
                }
            }
        }
        std::mem::swap(self.cur, self.next);
    }

    pub fn initialize_glider(&mut self, rnd: bool) {
        if rnd {
            for i in 0..self.n {
                for j in 0..self.n {
                    if (i + j) % 5 == 0 {
                        self.cur.board[i][j] = 1;
                    }
                }
            }
        } else {
            self.cur.board[0][1] = 1;
            self.cur.board[1][2] = 1;
            self.cur.board[2][0] = 1;
            self.cur.board[2][1] = 1;
            self.cur.board[2][2] = 1;
        }
    }
}

fn main() {
    let dt1 = Local::now();

    let args = Args::parse();
    let b1 = vec![vec![0; args.size]; args.size];
    let b2 = vec![vec![0; args.size]; args.size];
    let mut cur = BoardResources { board: b1 };
    let mut next = BoardResources { board: b2 };
    let mut board = Board::new(args.size, &mut cur, &mut next);
    let mut iters: u32 = 0;

    board.initialize_glider(args.rnd);
    loop {
        if args.display == true {
            board.board_render(iters);
        }
        board.update();
        thread::sleep(time::Duration::from_millis(args.lag));
        iters += 1;
        if iters >= args.iters {
            break;
        }
    }
    if args.display == true {
        board.board_render(iters);
    }
    let dt2 = Local::now();
    println!(
        "It took {:?} milliseconds to run",
        (dt2.sub(dt1)).num_milliseconds()
    );
}
