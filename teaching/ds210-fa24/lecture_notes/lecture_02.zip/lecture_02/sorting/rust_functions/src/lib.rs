use rayon::prelude::*;

#[no_mangle]
pub extern "C" fn add(x:i32, y:i32) -> i32 {
    x + y
}


#[no_mangle]
pub extern "C" fn sort(pointer:usize, length:usize) -> () {
    let p = unsafe {
        std::mem::transmute::<usize,*mut i32>(pointer)
    };
    let slice = unsafe {
        std::slice::from_raw_parts_mut(p, length)
    };
    slice.sort_unstable();
}

#[no_mangle]
pub extern "C" fn sort_par(pointer:usize, length:usize) -> () {
    let p = unsafe {
        std::mem::transmute::<usize,*mut i32>(pointer)
    };
    let slice = unsafe {
        std::slice::from_raw_parts_mut(p, length)
    };
    slice.par_sort_unstable();
}
