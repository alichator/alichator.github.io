#!/Library/Frameworks/Python.framework/Versions/3.8/bin/python3.8
import numpy as np
from cffi import FFI
import timeit
import random

def time_it_start():
    return timeit.default_timer()

def time_it_stop(before):
    duration = timeit.default_timer() - before
    print(f"Time: {duration:.3f} s")

def random_array(size=10):
    rng = np.random.default_rng()
#    a = rng.integers(1000000000, size=size, dtype='int32')
    a = rng.integers(1000000000, size=size)
    return a

def python_sort(l):
    print("=== python sort ===")
    t = time_it_start()
    l.sort()
    time_it_stop(t)
    return l

def numpy_sort(arr):
    print("=== numpy sort ===")
    t = time_it_start()
    sorted = np.sort(arr)
    time_it_stop(t)
    return sorted

def rust_sort(arr, C):
    print("=== rust sort ===")
    t = time_it_start()
    C.sort(arr.__array_interface__['data'][0], np.size(arr))
    time_it_stop(t)
    return arr

def rust_sort_par(arr, C):
    print("=== rust sort parallel ===")
    t = time_it_start()
    C.sort_par(arr.__array_interface__['data'][0], np.size(arr))
    time_it_stop(t)
    return arr

ffi = FFI()
ffi.cdef("""
        void sort(uint64_t,uint32_t);
        void sort_par(uint64_t,uint32_t);
""")

C = ffi.dlopen("rust_functions/target/release/librust_functions.dylib")

array_length = 100 * 1000 * 1000;
arr = random_array(array_length)
lst = arr.tolist()

out0 = python_sort(lst)
out1 = numpy_sort(arr.copy())
out2 = arr.copy()
rust_sort(out2, C)
out3 = arr.copy()
rust_sort_par(out3, C)

print(arr)
print(out0[:3],out0[-3:])
print(out1)
print(out2)
print(out3)
