use librs;
fn main() {
   println!("This is main using a library");
   librs::bar::say_something();
}
